<?php

    $koneksi= mysqli_connect('localhost', 'root', '', 'skanshop');
    if(!$koneksi){
        echo "koneksi Gagal";
    }
    

?>